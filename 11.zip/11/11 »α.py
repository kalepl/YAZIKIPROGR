from tkinter import *
import tkinter as tk
from tkinter import messagebox
import json

def write():
    if repository.get() == "Microsoft visual studio code":
        with open("data.txt",'w',encoding='utf-8') as file:
            json.dump(data_2,file,indent=4)
        messagebox.showinfo('Save', 'File saved as data')
    else:
        messagebox.showerror('Error', 'Попробуйте ещё раз!  Репозиторий не найден')

str_json1="""
{
"company": null,
"created_at": "2019-09-03T9:42:22Z",
"email": null,
"id": 5638672890,
"name": "Microsoft visual studio code",
"url": "https://github.com/Microsoft/vscode"
}"""
data_2 = json.loads(str_json1)
win = Tk()
win.geometry(f"600x200+100+200")
win['bg'] ='#e6e6fa'
win.title('Рябцев Максим Юрьевич')
repository = StringVar()
lbl = Label(win, text="Введите репозиторий",bg="#e6e6fa",fg='#013220')
lbl.grid(column=250, row=250)
lbl.place(x=300, y=60,width=170, height=160,anchor=CENTER)
vvod = Entry(win,textvariable=repository)
vvod.place(x=200, y=100, width=210, height=20)
Enter = Button(win,text = 'Enter',bg='#da70d6',fg='#013220',activebackground='#013220',      
          activeforeground='#da70d6',command=write)
Enter.place(x=420, y=100, width=50, height=20)

win.mainloop()
