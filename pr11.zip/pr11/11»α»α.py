import requests
from tkinter import messagebox
import json
from tkinter import *
from tkinter import scrolledtext

def func():
    repo = repository.get()
    r = requests.get(f'https://api.github.com/repos/{repo}/{repo}')

    with open("C:\\Users\\Max\\Desktop\\pr11\\data.txt", 'a+') as f:
        if 'company' in r.json():
            f.write(f"'company': '{r.json()['company']}'\n")
        else:
            f.write("company: ")
            f.write('None\n')
        if 'created_at' in r.json(): 
            f.write(f"'created_at': '{r.json()['created_at']}'\n")
        else:
            f.write("createt_at: ")
            f.write("'None\n'")
        if 'email' in r.json():
            f.write(f"email': '{r.json()['email']}'\n")
        else:
            f.write("email: ")
            f.write('None\n')
        if 'id' in r.json():
            f.write(f"'id': '{r.json()['id']}'\n")
        else:
            f.write("id: ")
            f.write('None\n')
        if 'name' in r.json():
            f.write(f"'name': '{r.json()['name']}'\n")
        else:
            f.write("name: ")
            f.write('None\n')
        if 'url' in r.json():
            f.write(f"'url': '{r.json()['url']}'\n")
        else:
            f.write("url: ")
            f.write('None\n')

        print('Результат получен')

win = Tk()
win.geometry(f"600x200+100+200")
win['bg'] ='#e6e6fa'
win.title('Рябцев Максим Юрьевич')
repository = StringVar()
lbl = Label(win, text="Введите репозиторий",bg="#e6e6fa",fg='#013220')
lbl.grid(column=250, row=250)
lbl.place(x=300, y=60,width=170, height=160,anchor=CENTER)
vvod = Entry(win,textvariable=repository)
vvod.place(x=200, y=100, width=210, height=20)
Enter = Button(win,text = 'Enter',bg='#da70d6',fg='#013220',activebackground='#013220',      
          activeforeground='#da70d6',command=func)
Enter.place(x=420, y=100, width=50, height=20)

win.mainloop()